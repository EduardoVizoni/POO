package org.example;

public class Alimento {

    private static int geradorCodigo = 1;
    private final int codigo;
    private final String nome;
    private final int nutricao;

    public Alimento(String nome, int nutricao) {
        this.codigo = geradorCodigo;
        this.nome = nome;
        this.nutricao = nutricao;
        geradorCodigo++;
    }

    public int getNutricao(){
        return nutricao;
    }

    public int getCodigo() {
        return codigo;
    }
}
