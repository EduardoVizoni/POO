package org.example;

public class Pessoa {
    private long cpf;
    private String nome;
    private String senha;
    private Pet pet;

    public Pessoa(long cpf, String nome, String senha) {
        this.cpf = cpf;
        this.nome = nome;
        this.senha = senha;
    }

    public long getCpf() {
        return cpf;
    }

    public String getSenha() {
        return senha;
    }

    public void botaPetParaDormir() {
        if (pet != null) {
            pet.dormir();
        }
    }

    public void acordarPet() {
        if (pet != null) {
            pet.acordar();
        }
    }

    public void adotarPet(Pet pet) {
        this.pet = pet;
    }

    public void darAguaParaPet() {
        if (pet != null) {
            pet.beberAgua();
        }
    }

    public void brincarComPet(Brincadeira brindaceira) {
        if (pet != null) {
            pet.brincar(brindaceira);
        }
    }

    public void alimentarPet(Alimento alimento) {
        if (pet != null) {
            pet.comer(alimento);
        }
    }

    public void levarPetParaFazerNecessidades() {
        if (pet != null) {
            pet.fazerNecessidades();
        }
    }

    public void limparPet() {
        if (pet != null) {
            pet.limpar();
        }
    }

    public String avaliarPet() {
        if (pet == null) {
            return "Sem pet";
        }
        return pet.toString();
    }

    @Override
    public String toString() {
        return "CPF: " + cpf + "\n" +
               "Nome: " + nome + "\n" +
               "Pet: " + pet;
    }
}
