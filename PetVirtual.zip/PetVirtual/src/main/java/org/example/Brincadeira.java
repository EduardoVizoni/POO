package org.example;

public class Brincadeira {
    private static int geradorCodigo = 0;
    private final int codigo;
    private final String nome;
    private final int divertimento;
    private final int cansaco;
    private final int fome;
    private final int sede;
    private final int sujeira;

    public Brincadeira(String nome, int divertimento, int cansaco, int fome, int sede, int sujeira) {
        this.codigo = geradorCodigo+1;
        this.nome = nome;
        this.divertimento = divertimento;
        this.cansaco = cansaco;
        this.fome = fome;
        this.sede = sede;
        this.sujeira = sujeira;
        geradorCodigo++;
    }

    public int getDivertimento(){
        return divertimento;
    }
    public int getCansaco(){
        return cansaco;
    }
    public int getFome(){
        return fome;
    }
    public int getSede(){
        return sede;
    }
    public int getSujeira(){
        return sujeira;
    }

    public int getCodigo() {
        return codigo;
    }
}
