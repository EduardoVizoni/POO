package org.example;

public class Pet {
    private static int geradorCodigo = 0;
    private final int codigo;
    private final String nome;
    private boolean vivo;
    private boolean acordado;
    private int sede;
    private int fome;
    private int energia;
    private int diversao;
    private int higiene;
    private int vontadeBanheiro;

    public Pet(String nome) {
        this.codigo = geradorCodigo + 1;
        this.nome = nome;
        geradorCodigo++;
        this.vivo = true;
        this.acordado = true;
        this.sede = 100;
        this.fome = 100;
        this.energia = 100;
        this.diversao = 100;
        this.higiene = 100;
        this.vontadeBanheiro = 100;
    }

    public int getCodigo() {
        return codigo;
    }

    public void beberAgua() {
        if (vivo) {
            if (acordado) {
                if (sede <= 50) {
                    sede += 50;
                } else {
                    sede = 100;
                }
                if (vontadeBanheiro > 25) {
                    vontadeBanheiro -= 25;
                } else {
                    vontadeBanheiro = 100;
                    higiene = 0;
                }
            }
        }
    }

    public void comer(Alimento alimento) {
        if (vivo) {
            if (acordado) {
                int nutricao = alimento.getNutricao();
                if (fome + nutricao < 100) {
                    fome += nutricao;
                } else {
                    fome = 100;
                }
                if (vontadeBanheiro > nutricao / 2) {
                    vontadeBanheiro -= nutricao / 2;
                } else {
                    vontadeBanheiro = 100;
                    higiene = 0;
                }
            }
        }
    }

    public void dormir() {
        if (vivo) {
            if (acordado) {
                if (energia < 75) {
                    energia += 25;
                } else {
                    energia = 100;
                }
                acordado = false;
            }
        }
    }

    public void acordar() {
        if (vivo) {
            if (!acordado) {
                if (energia <= 75) {
                    energia += 25;
                } else {
                    energia = 100;
                }
                acordado = true;
            }
        }
    }

    public void brincar(Brincadeira brincadeira) {
        if (vivo) {
            if (acordado) {
                int divertimento = brincadeira.getDivertimento();
                int cansaco = brincadeira.getCansaco();
                int comida = brincadeira.getFome();
                int agua = brincadeira.getSede();
                int sujeira = brincadeira.getSujeira();
                if (energia <= cansaco) {
                    energia = 0;
                }
                if (fome <= comida) {
                    fome = 0;
                }
                if (sede <= agua) {
                    sede = 0;
                }
                if (energia <= cansaco || fome <= comida ||
                    sede <= agua) {
                    morrer();
                } else {
                    if (diversao + divertimento <= 100) {
                        diversao += brincadeira.getDivertimento();
                    } else {
                        diversao = 100;
                    }
                    energia -= brincadeira.getCansaco();
                    fome -= brincadeira.getFome();
                    sede -= brincadeira.getSede();
                    if (higiene >= sujeira) {
                        higiene -= brincadeira.getSujeira();
                    } else {
                        higiene = 0;
                    }
                }
            }
        }
    }

    public void limpar() {
        if (vivo) {
            if (acordado) {
                higiene = 100;
            }
        }
    }

    public void fazerNecessidades() {
        if (vivo) {
            if (acordado) {
                vontadeBanheiro = 100;
                higiene -= 25;
            }
        }
    }

    public void morrer() {
        if (sede <= 0 || fome <= 0 || energia <= 0) {
            vivo = false;
        }
    }

    public String toString() {
        return "Nome: " + nome + "\n" +
               "Vivo: " + (vivo ? "Sim" : "Não") + "\n" +
               "Acordado: " + (acordado ? "Sim" : "Não") + "\n" +
               "Sede: " + sede + "\n" +
               "Fome: " + fome + "\n" +
               "Energia: " + energia + "\n" +
               "Diversão: " + diversao + "\n" +
               "Higiene: " + higiene + "\n" +
               "Vontade de ir ao banheiro: " + vontadeBanheiro + "\n";
    }
}
