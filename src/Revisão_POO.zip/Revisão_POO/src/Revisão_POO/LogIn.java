package Revisão_POO;

//LogIn: Gerencia a autenticação.
public class LogIn {
    private String user;
    private String senha;

    public String getUser() {
        return user;
    }

    public String getSenha() {
        return senha;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
